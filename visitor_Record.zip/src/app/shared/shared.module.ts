import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './component/sections/navbar/navbar.component';
import { NgbAccordionModule, NgbPaginationModule, NgbAlertModule, NgbModule, NgbCollapseModule, NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserModule } from '@angular/platform-browser';
import { TableComponent } from './component/sections/table/table.component';
import { SigninComponent } from './component/pages/signin/signin.component';
import { SignupComponent } from './component/pages/signup/signup.component';
import { DashboardComponent } from './component/pages/dashboard/dashboard.component';
import { CardIconComponent } from './component/sections/card-icon/card-icon.component';



@NgModule({
  declarations: [
    NavbarComponent,
    TableComponent,
    SigninComponent,
    SignupComponent,
    DashboardComponent,
    CardIconComponent,
  ],
  imports: [ 
    CommonModule,
    BrowserModule,
    NgbModule,
    NgbDropdownModule,
  ],
  exports : [
    SigninComponent,
    SignupComponent,
    DashboardComponent,
  ],
})
export class SharedModule { 
  public isCollapsed = false;
}
  