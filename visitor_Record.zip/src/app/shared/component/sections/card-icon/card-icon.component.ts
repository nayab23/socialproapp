import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-icon',
  templateUrl: './card-icon.component.html',
  styleUrls: ['./card-icon.component.css']
})
export class CardIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
